Script Wizard Animset v1.0
https://assetstore.unity.com/packages/3d/animations/script-wizard-anim-set-186463
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/70c27330-af5f-41db-9cde-dcc29f1a11bc.webp "在这里输入图片标题")

Rapier Anim Set v1.0
https://assetstore.unity.com/packages/3d/animations/rapier-anim-set-148084
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/08158269-6772-47d7-98ae-97d9be06ec0b.webp "在这里输入图片标题")