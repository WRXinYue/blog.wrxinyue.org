请点击左侧分页切换页面；

Shooter Motion Pack
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/e1f86e58-91ed-4c68-8b3f-90f6488cf0c4.webp "在这里输入图片标题")
https://send.cm/d/AoXE


Amplify Animation Pack
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/809da763-6c54-4f4a-bf24-c8eaba28e900.webp "在这里输入图片标题")
https://mega.nz/file/bkERVTLB#iAfkcC7LlucPI9KSzAiz5yWIP4Gtu_L7IeEcCyjSMjE

Insane Gunner Set
https://assetstore.unity.com/packages/3d/animations/insane-gunner-set-142038
https://www56.zippyshare.com/v/BQTZgLXB/file.html


TKDstyle AnimSet
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/33a45424-8e7f-4cfa-a801-f901dabced3b.webp "在这里输入图片标题")
https://send.cm/9fwsokwe76oq


frank climax 
Frank Slash Pack 5 + 2 ( Katana, Assassin, Warrior, Dual, 2Handed + Spear, Great Sword)
[Asset store](https://assetstore.unity.com/packages/3d/animations/frank-slash-pack-5-2-katana-assassin-warrior-dual-2handed-spear--141184)
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/a2540b19-0324-4d4b-90c0-81057ba7ba8b.webp "在这里输入图片标题")
https://www.bilibili.com/video/BV1wU4y1t7Yt
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/3a2a659a-f901-4217-a347-003f669815c1.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/ff429fec-03a8-49a7-b796-9de5cc9fc453.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/812e2790-4ed3-4c2b-8191-6ebbc76ed4ec.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/fb5e4a4a-eccd-4f84-bd60-d830ce045678.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/b629bd49-1b70-4aad-b6bc-5d496c5ff020.webp "在这里输入图片标题")



DL:https://pan.baidu.com/s/1h89MznVoEHediPtBAJakyQ 
提：hj1w

Powerful Sword Pack(Great Sword + Katana)
https://assetstore.unity.com/packages/3d/animations/powerful-sword-pack-great-sword-katana-183324
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/997f5921-e0c6-40e5-8e14-00fdac812bd5.webp "在这里输入图片标题")
DL:https://www.bilibili.com/video/BV1pv4y1f7AP
https://www35.zippyshare.com/v/rgbqRLjz/file.html
https://unrealengine.lanzoui.com/iBAv6sgwaij 码:bmqy