Welcome to the Synty Store-polygon wiki!
更多下载 https://gitee.com/bilibili-lilith/unity-plugin/wikis/Home

POLYGON Horror Mansion - Low Poly 3D Art by Synty
https://assetstore.unity.com/packages/3d/environments/fantasy/polygon-horror-mansion-low-poly-3d-art-by-synty-213346
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/8ebd04dc-80b3-4f21-8d92-df3948a71f8b.webp "在这里输入图片标题")
https://www86.zippyshare.com/v/1vNFp1Bo/file.html
https://send.cm/8qvo50h4r9vh

POLYGON Shops Pack - Low Poly 3D Art by Synty
https://assetstore.unity.com/packages/3d/environments/urban/polygon-shops-pack-low-poly-3d-art-by-synty-199026
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/4dd727c9-fee0-4a69-8324-3f7d3be8fe3f.webp "在这里输入图片标题")
下载https://www36.zippyshare.com/v/NR5UFkTH/file.html
链接：https://pan.baidu.com/s/1Q0jLwTRX6BwOfY1r2wdXJg 
提取码：sbem

POLYGON - Street Racer - Low Poly 3D Art by Synty
https://assetstore.unity.com/packages/3d/vehicles/land/polygon-street-racer-low-poly-3d-art-by-synty-194800
![输入图片说明](https://assetstorev1-prd-cdn.unity3d.com/key-image/bcba7bfd-02ea-422e-b633-691ec7e9a6d6.webp "在这里输入图片标题")
下载https://www66.zippyshare.com/v/VWjbhpSI/file.html
链接：https://pan.baidu.com/s/1hNpdA3m3fZfaBGoPlBhgiQ 
提取码：87nu

POLYGON - Sci-Fi Worlds Pack（原价500美金）
![输入图片说明](https://cdn.shopify.com/s/files/1/2231/6843/products/Icon_Unity_f9af73b1-f278-4d97-b65d-3cd5b06b6bc4_1024x1024@2x.png?v=1635474183 "在这里输入图片标题")
https://syntystore.com/products/polygon-sci-fi-worlds
下载：https://pan.baidu.com/s/1jUW7PHJzszjVoH4iNdk9Iw 
提码：ruoq

POLYGON Apocalypse - Low Poly 3D Art by Synty
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/3562e295-1b9c-41a4-b580-c8c82a22291d.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/0fb4d192-c582-4cc3-9ec2-b428233f7159.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/afab1bbe-4495-49cd-bc5f-6e6a298e00dc.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/4dc4f6b4-2eaf-41bd-9bbe-2d6bc3c6b195.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/bcba7bfd-02ea-422e-b633-691ec7e9a6d6.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/8b30cb0f-cadc-49e5-b7d9-b65dd47dd3fb.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/d2716609-9b4c-4412-ab62-507f03fe7d07.webp "在这里输入图片标题")
![输入图片说明](https://assetstore-cdn-china-v1.unitychina.cn/key-image/5a5e9f5b-1dc7-48a0-ae9f-e501ad3f3413.webp "在这里输入图片标题")
下载见：https://space.bilibili.com/2603430/channel/detail?cid=140053&ctype=0
unity：https://pan.baidu.com/s/1cLa1WwTDdRhswAh2H8nwqw 
PASS：1tmf
UE4：https://pan.baidu.com/s/15b2FH6o_UfJdGyn6kUx65A 
PASS：cab8 
