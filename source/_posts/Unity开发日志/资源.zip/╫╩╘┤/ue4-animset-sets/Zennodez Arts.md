Female Shooter Character Template
https://www.unrealengine.com/marketplace/zh-CN/product/female-shooter-character-template
![输入图片说明](https://cdn1.epicgames.com/ue/product/Screenshot/SCR0001-1920x1080-ca1608401d95d6aa516934104a355ebd.jpg?resize=1&w=1920 "在这里输入图片标题")
https://www.bilibili.com/video/BV16K411w7hV
下载:https://unrealengine.lanzoui.com/i1UMCw13qxa 码:98v3