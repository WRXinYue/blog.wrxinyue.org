Mumble's Action Crossbow
https://www.unrealengine.com/marketplace/zh-CN/product/mumble-s-action-crossbow
![输入图片说明](https://cdn1.epicgames.com/ue/product/Screenshot/Crossbow2a-1920x1080-fc96c914d87a52df31b7946a3208a664.png?resize=1&w=1920 "在这里输入图片标题")
https://www.bilibili.com/video/BV1Nb4y1o7K4
下载:https://unrealengine.lanzoui.com/is5Faw14k5c 码:hgtg