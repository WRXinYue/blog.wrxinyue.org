Essential Sword & Shield Animations
![输入图片说明](https://cdn1.epicgames.com/ue/product/Screenshot/Desktop%20Screenshot%202021.04.06%20-%2017.55.04.27-1920x1080-ea763f91a63570365ce3b3a415f14503.png?resize=1&w=1920 "在这里输入图片标题")
https://www.unrealengine.com/marketplace/en-US/product/essential-sword-shield-animations
V:https://www.bilibili.com/video/BV1Gf4y1N7NR
DL：https://disk.yandex.ru/d/HUXBiGTocuJ4bg

Essential Spear And Shield Animation Pack
![输入图片说明](https://cdn1.epicgames.com/ue/product/Screenshot/Desktop%20Screenshot%202021.08.18%20-%2022.15.07.91-1920x1080-d9cfa0c5fc95d22ce0466db23540ad04.png?resize=1&w=1920 "在这里输入图片标题")
https://www.unrealengine.com/marketplace/zh-CN/product/essential-spear-and-shield-animation-pack
https://www.bilibili.com/video/BV1xM4y1V7vv
DL:https://unrealengine.lanzoui.com/i4jq5vvy2eh 码:c937