Two types Powerful Sword Pack
https://www.unrealengine.com/marketplace/zh-CN/product/grruzam-powerful-sword-pack
![输入图片说明](https://cdn1.epicgames.com/ue/product/Screenshot/UR4GrruzamTitleyoutube-1920x1080-f0eb75f869452adcdf23be4e903853b9.jpg?resize=1&w=1920 "在这里输入图片标题")
https://www.bilibili.com/video/BV1pv4y1f7AP
DL：https://disk.yandex.ru/d/0yDwjWiTYAi-Hw

Powerful Fighter Pack
![输入图片说明](https://cdn1.epicgames.com/ue/product/Screenshot/1920x1080-1920x1080-9d25edc09fac1ec61562a75a80f9f710.jpg?resize=1&w=1920 "在这里输入图片标题")
https://www.unrealengine.com/marketplace/zh-CN/product/powerful-fighter-pack
视频：https://www.bilibili.com/video/BV1VP4y1p7pA
DL:https://unrealengine.lanzoui.com/iRNtevvwyeh 密码:hy4c